import java.util.*;

public class Main {
    static Scanner input = new Scanner(System.in);
    static ArrayList<Dosen> listDosen = new ArrayList<>();

    public static void main(String[] args) {
        int pilihan;
        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Tambah Data Dosen");
            System.out.println("2. Tampilkan Semua Data Dosen");
            System.out.println("3. Urutkan Berdasarkan NIDN (Ascending)");
            System.out.println("4. Cari Dosen Berdasarkan Nama");
            System.out.println("5. BONUS: Urutkan Berdasarkan Masa Kerja");
            System.out.println("0. Keluar");
            System.out.print("Pilih: ");
            pilihan = input.nextInt();
            input.nextLine(); // buang newline

            switch (pilihan) {
                case 1: tambahData(); break;
                case 2: tampilkanData(); break;
                case 3: urutkanNIDN(); break;
                case 4: cariNama(); break;
                case 5: urutkanMasaKerja(); break;
                case 0: System.out.println("Terima kasih."); break;
                default: System.out.println("Pilihan tidak valid."); break;
            }
        } while (pilihan != 0);
    }

    static void tambahData() {
        System.out.print("NIDN: ");
        String nidn = input.nextLine();
        System.out.print("Nama: ");
        String nama = input.nextLine();
        System.out.print("Email: ");
        String email = input.nextLine();
        System.out.print("Tahun Masuk: ");
        int tahunMasuk = input.nextInt(); input.nextLine();
        System.out.print("Program Studi: ");
        String prodi = input.nextLine();

        listDosen.add(new Dosen(nidn, nama, email, tahunMasuk, prodi));
        System.out.println("Data berhasil ditambahkan.");
    }

    static void tampilkanData() {
        for (Dosen d : listDosen) {
            d.tampilkan();
        }
    }

    static void urutkanNIDN() {
        for (int i = 0; i < listDosen.size(); i++) {
            for (int j = 0; j < listDosen.size() - i - 1; j++) {
                if (listDosen.get(j).nidn.compareTo(listDosen.get(j+1).nidn) > 0) {
                    Collections.swap(listDosen, j, j+1);
                }
            }
        }
        System.out.println("Data berhasil diurutkan berdasarkan NIDN.");
    }

    static void cariNama() {
        System.out.print("Masukkan nama yang dicari: ");
        String keyword = input.nextLine().toLowerCase();
        boolean ditemukan = false;

        for (Dosen d : listDosen) {
            if (d.nama.toLowerCase().contains(keyword)) {
                d.tampilkan();
                ditemukan = true;
            }
        }

        if (!ditemukan) {
            System.out.println("Data tidak ditemukan.");
        }
    }

    static void urutkanMasaKerja() {
        for (int i = 0; i < listDosen.size(); i++) {
            int idxMax = i;
            for (int j = i+1; j < listDosen.size(); j++) {
                if (listDosen.get(j).getMasaKerja() > listDosen.get(idxMax).getMasaKerja()) {
                    idxMax = j;
                }
            }
            Collections.swap(listDosen, i, idxMax);
        }
        System.out.println("Data berhasil diurutkan berdasarkan masa kerja.");
    }
}
