import java.util.Calendar;

public class Dosen {
    String nidn, nama, email, programStudi;
    int tahunMasuk;

    public Dosen(String nidn, String nama, String email, int tahunMasuk, String programStudi) {
        this.nidn = nidn;
        this.nama = nama;
        this.email = email;
        this.tahunMasuk = tahunMasuk;
        this.programStudi = programStudi;
    }

    public int getMasaKerja() {
        int tahunSekarang = Calendar.getInstance().get(Calendar.YEAR);
        return tahunSekarang - tahunMasuk;
    }

    public void tampilkan() {
        System.out.println("NIDN: " + nidn);
        System.out.println("Nama: " + nama);
        System.out.println("Email: " + email);
        System.out.println("Tahun Masuk: " + tahunMasuk);
        System.out.println("Program Studi: " + programStudi);
        System.out.println("Masa Kerja: " + getMasaKerja() + " tahun");
        System.out.println("--------------------------------");
    }
}
